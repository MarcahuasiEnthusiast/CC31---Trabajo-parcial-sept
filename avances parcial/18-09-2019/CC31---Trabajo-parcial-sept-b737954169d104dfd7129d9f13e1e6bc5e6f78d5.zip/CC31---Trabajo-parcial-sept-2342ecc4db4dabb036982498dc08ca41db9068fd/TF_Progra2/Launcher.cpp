#include "FrmMenu.h"
#include "FrmNivel1.h"


using namespace TF_Progra2;

int main() {

	srand(time(NULL));
	Application::Run(gcnew FrmMenu());


	return 0;

}